Warm Warm Studios

=== Controls ===
Move - WASD
Light Attack - LEFT MOUSE BUTTON
Heavy Attack - RIGHT MOUSE BUTTON
Dash/Dodge - Spacebar

=== Cheatcode ===
1. Time Fracture: V

=== Notes ===
1. Can use F to damage the player
2. SHIFT to see the VFX planned for activating a buff.
3. The prototype ends when the 2 enemies are killed.

=== Known Issues ===
1. Player falls off the rail cart.
2. Player still takes damage in Time Fracture.
3. Player jittering when on the pistons.